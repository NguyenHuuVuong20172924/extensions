function execute(url) {
    const cookie = Http.get("https://forum.dichtienghoa.com/").cookie() + ";wkdth_code=eden";
    return Response.success(Http.get(url).headers({"Cookie": cookie}).html().select("div#bookContentBody").html());
}