
function execute() {
    var cookie = Http.get("https://dichtienghoa.com").cookie() + ";wkdth_code=eden";
    const doc = Http.get("https://koanchay.com/bang-xep-hang").headers({"Cookie": cookie}).html();
    const el = doc.select("div.tag-tabs .tag-tab a");
    const data = [];
    for (var i = 0; i < el.size(); i++) {
        var e = el.get(i);
        data.push({
           title: e.text(),
           input: 'https://koanchay.com' + e.attr('href'),
           script: 'gen.js'
        });
    }
    return Response.success(data);
}