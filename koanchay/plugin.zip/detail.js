function execute(url) {
    const cookie = Http.get("https://forum.dichtienghoa.com/").cookie() + ";wkdth_code=eden";
    const doc = Http.get(url).headers({"Cookie": cookie}).html()

    var name = doc.select(".cover-info h2").text();
    var author = doc.html().match(/tac-gia.*?>(.*?)</);
    if (author) author = author[1];

    var element = doc.select("div.cover-info").first();
    element.select("h2,span,i").remove();

    return Response.success({
        name: name,
        cover: doc.select("div.book-info img").first().attr("src"),
        author: author,
        description: doc.select("div.book-desc-detail").html(),
        detail: element.html(),
        host: "https://koanchay.com",
        ongoing: doc.select(".cover-info").html().indexOf("Còn tiếp") > 0
    });
}