function execute() {
    return Response.success([
        {title: "Bảng xếp hạng", script: "gen.js", input: "https://koanchay.com/bang-xep-hang"}
    ]);
}