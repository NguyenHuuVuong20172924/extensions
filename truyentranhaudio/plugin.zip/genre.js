function execute() {
    return Response.success([
        {title: "Action", input: "https://truyentranhaudio.online/manga-genre/action/", script: "gen.js"},
        {title: "Adventure", input: "https://truyentranhaudio.online/manga-genre/adventure/", script: "gen.js"},
        {title: "AUDIO", input: "https://truyentranhaudio.online/manga-genre/audio/", script: "gen.js"},
        {title: "Bl", input: "https://truyentranhaudio.online/manga-genre/bl/", script: "gen.js"},
        {title: "Comedy", input: "https://truyentranhaudio.online/manga-genre/comedy/", script: "gen.js"},
        {title: "Cung Đấu", input: "https://truyentranhaudio.online/manga-genre/cung-dau/", script: "gen.js"},
        {title: "ĐA QUỐC GIA", input: "https://truyentranhaudio.online/manga-genre/da-quoc-gia/", script: "gen.js"},
        {title: "Đấu Trí", input: "https://truyentranhaudio.online/manga-genre/dau-tri/", script: "gen.js"},
        {title: "ĐÔ THỊ", input: "https://truyentranhaudio.online/manga-genre/do-thi/", script: "gen.js"},
        {title: "ECCHI", input: "https://truyentranhaudio.online/manga-genre/ecchi/", script: "gen.js"},
        {title: "Fantasy", input: "https://truyentranhaudio.online/manga-genre/fantasy/", script: "gen.js"},
        {title: "GAME", input: "https://truyentranhaudio.online/manga-genre/game/", script: "gen.js"},
        {title: "HAREM", input: "https://truyentranhaudio.online/manga-genre/harem/", script: "gen.js"},
        {title: "HỆ THỐNG", input: "https://truyentranhaudio.online/manga-genre/he-thong/", script: "gen.js"},
        {title: "Huyền Huyễn", input: "https://truyentranhaudio.online/manga-genre/huyen-huyen/", script: "gen.js"},
        {title: "LÃNG MẠN", input: "https://truyentranhaudio.online/manga-genre/lang-man/", script: "gen.js"},
        {title: "MANHUA", input: "https://truyentranhaudio.online/manga-genre/manhua/", script: "gen.js"},
        {title: "MANHWA", input: "https://truyentranhaudio.online/manga-genre/manhwa/", script: "gen.js"},
        {title: "Mạt Thế", input: "https://truyentranhaudio.online/manga-genre/mat-the/", script: "gen.js"},
        {title: "TRỌNG SINH", input: "https://truyentranhaudio.online/manga-genre/trong-sinh/", script: "gen.js"},
        {title: "Tu Chân", input: "https://truyentranhaudio.online/manga-genre/tu-chan/", script: "gen.js"},
        {title: "TU TIÊN", input: "https://truyentranhaudio.online/manga-genre/tu-tien/", script: "gen.js"},
        {title: "Tuyệt Thế", input: "https://truyentranhaudio.online/manga-genre/tuyet-the/", script: "gen.js"},
        {title: "VÕNG DU", input: "https://truyentranhaudio.online/manga-genre/vong-du/", script: "gen.js"},
        {title: "XUYÊN KHÔNG", input: "https://truyentranhaudio.online/manga-genre/xuyen-khong/", script: "gen.js"}
    ]);
}