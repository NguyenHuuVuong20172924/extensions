local url = ...
local doc = http:get(url):html()
if doc ~= nil then
    local book = {}
    book["name"] =  doc:select("h1"):text()
    book["cover"] = doc:select("div.book-img img"):attr("src")
    book["author"] = doc:select("div.book-information div.book-info a"):first():text()
    book["description"] = doc:select("div.book-info-detail div.book-intro"):html()
    book["detail"] = doc:select("p.tag"):html()
    book["host"] = "https://truyen.tangthuvien.vn"
    return response:success(book)
end
return nil