local doc = html:parse("<a href=\"danh-sach/truyen-moi/\">Truyện mới cập nhật</a><a href=\"danh-sach/truyen-hot/\">Truyện Hot</a><a href=\"danh-sach/tien-hiep-hay/\">Tiên Hiệp Hay</a><a href=\"danh-sach/kiem-hiep-hay/\">Kiếm Hiệp Hay</a><a href=\"danh-sach/truyen-teen-hay/\">Truyện Teen Hay</a><a href=\"danh-sach/ngon-tinh-hay/\">Ngôn Tình Hay</a><a href=\"danh-sach/ngon-tinh-sac/\">Ngôn Tình Sắc</a><a href=\"danh-sach/ngon-tinh-nguoc/\">Ngôn Tình Ngược</a><a href=\"danh-sach/ngon-tinh-sung/\">Ngôn Tình Sủng</a><a href=\"danh-sach/ngon-tinh-hai/\">Ngôn Tình Hài</a><a href=\"danh-sach/dam-my-hai/\">Đam Mỹ Hài</a><a href=\"danh-sach/dam-my-hay/\">Đam Mỹ Hay</a><a href=\"danh-sach/dam-my-h-van/\">Đam Mỹ H Văn</a><a href=\"danh-sach/dam-my-sac/\">Đam Mỹ Sắc</a><a href=\"the-loai/trong-sinh/\">Trọng Sinh</a><a href=\"the-loai/trinh-tham/\">Trinh Thám</a><a href=\"the-loai/tham-hiem/\">Thám Hiểm</a><a href=\"the-loai/linh-di/\">Linh Dị</a><a href=\"the-loai/sac/\">Sắc</a><a href=\"the-loai/nguoc/\">Ngược</a><a href=\"the-loai/sung/\">Sủng</a><a href=\"the-loai/cung-dau/\">Cung Đấu</a><a href=\"the-loai/nu-cuong/\">Nữ Cường</a><a href=\"the-loai/gia-dau/\">Gia Đấu</a><a href=\"the-loai/dong-phuong/\">Đông Phương</a><a href=\"the-loai/dam-my/\">Đam Mỹ</a><a href=\"the-loai/bach-hop/\">Bách Hợp</a>")

local genre = {}
if doc ~= nil then
    local el = doc:select("a")
    for i = 0, el:size() - 1 do
        local e = el:get(i)
        local link = {}
        link["title"] = e:text()
        link["input"] = "https://truyenfull.net/" .. e:attr("href")
        link["script"] = "gen.lua"
        table.insert(genre, link)
        link["title"] = e:text() .. " (Hoàn)"
        link["input"] = "https://truyenfull.net/" .. e:attr("href") .. "hoan"
        link["script"] = "gen.lua"
        table.insert(genre, link)
    end
    return response:success(genre)
end

return nil