local url = ...
local doc = http:get(url):html()
if doc ~= nil then
    local book = {}
    book["name"] =  doc:select("h3.title"):text()
    book["cover"] = doc:select("div.book img"):attr("src")
    book["host"] = "http://truyenfull.net"
    book["author"] = doc:select("div.info div a"):first():text()
    book["description"] = doc:select("div.desc-text"):html()
    book["detail"] = doc:select("div.info"):html()
    return response:success(book)
end
return nil