function execute() {
    return Response.success([
        {title: "Truyện Teen Hay", input: "https://sstruyen.com/danh-sach/truyen-teen-hay/", script: "gen.js"},
        {title: "Ngôn Tình Ngược", input: "https://sstruyen.com/danh-sach/ngon-tinh-nguoc/", script: "gen.js"},
        {title: "Ngôn Tình Hài", input: "https://sstruyen.com/danh-sach/ngon-tinh-hai/", script: "gen.js"},
        {title: "Đam Mỹ Hài", input: "https://sstruyen.com/danh-sach/dam-my-hai/", script: "gen.js"},
        {title: "Đam Mỹ Hay", input: "https://sstruyen.com/danh-sach/dam-my-hay/", script: "gen.js"},
        {title: "Đam Mỹ H Văn", input: "https://sstruyen.com/danh-sach/dam-my-h-van/", script: "gen.js"},
        {title: "Ngôn Tình Hay", input: "https://sstruyen.com/danh-sach/ngon-tinh-hay/", script: "gen.js"},
        {title: "Truyện Full", input: "https://sstruyen.com/danh-sach/truyen-full/", script: "gen.js"},
        {title: "Tiên Hiệp Hay", input: "https://sstruyen.com/danh-sach/tien-hiep-hay/", script: "gen.js"},
        {title: "Ngôn Tình Sắc", input: "https://sstruyen.com/danh-sach/ngon-tinh-sac/", script: "gen.js"},
        {title: "Truyện Hot", input: "https://sstruyen.com/danh-sach/truyen-hot/", script: "gen.js"},
        {title: "Kiếm Hiệp Hay", input: "https://sstruyen.com/danh-sach/kiem-hiep-hay/", script: "gen.js"},
        {title: "Truyện mới cập nhật", input: "https://sstruyen.com/danh-sach/truyen-moi-cap-nhat/", script: "gen.js"}
    ]);
}