function execute(url) {
    const doc = Http.get(url).html()

    var detail = doc.select(".content1 div.info").html();
    doc.select(".content1 div.info").remove()
    return Response.success({
        name: doc.select("ht.title").text(),
        cover: doc.select("div.wrap-detail img").first().attr("src"),
        author: doc.select(".content1 div.info a").first().text(),
        description: doc.select(".content1").html(),
        detail: detail,
        host: "https://sstruyen.com",
        ongoing: doc.select(".content1 .status").html().indexOf("Đang ra") > 0
    });
}