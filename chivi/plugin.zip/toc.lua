local url = ...
local doc = http:get(url):html()
if doc ~= nil then
    local list = {}
    local api = text:replace(url, "/chivi.xyz/", "/chivi.xyz/api/books/")
    local sources = doc:select(".sources"):attr("data-active")
    local json = http:get(api .. "/" .. sources .. "?reload=false"):table()

    local data = json["chlist"]
    for k, v in ipairs(data) do
        local chap = {
            ["name"] = v["vi_title"],
            ["url"] = url .. "/" .. v["title_slug"] .. "-" .. sources .. "-" .. v["csid"],
            ["host"] = "https://chivi.xyz/",
        }
        table.insert(list, chap)
    end

    return response:success(list)
end
return nil