local url = ...
local doc = http:get(url):html()
doc:select("__hover").remove()
return response:success(doc:select("article.convert"):html())