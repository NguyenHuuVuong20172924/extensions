function execute(url) {
    var doc = Http.get(url).html();
    return Response.success(doc.select(".page-chapter").html());
}