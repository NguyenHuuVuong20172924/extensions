local url = ...
local doc = http:get(url):html()
local imgs = doc:select(".story-see-content img.lazy")
local data = {}
if (imgs:size() == 0) then
    local cookie = regexp:find(doc:html(), "document.cookie=\"(.*?)\"")
    doc = http:get(url):header("Cookie", cookie):html()
    imgs = doc:select(".story-see-content img.lazy")
end
for i = 0, imgs:size() - 1 do
    local e = imgs:get(i)
    table.insert(data, {
        ["link"] = e:attr("src") .. "&mobile=2"
    })
end
return response:success(data)