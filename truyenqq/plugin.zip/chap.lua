local url = ...
local doc = http:get(url):timeout(0):html()
local imgs = doc:select(".story-see-content img.lazy")
local data = {}
for i = 0, imgs:size() - 1 do
    local e = imgs:get(i)
    table.insert(data, {
        ["link"] = e:attr("src") .. "&mobile=2"
    })
end
return response:success(data)