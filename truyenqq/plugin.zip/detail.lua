local url = ...
local doc = http:get(url):html()
if doc ~= nil then
    local book = {
        ["name"] = doc:select("h1[itemprop=name]"):text(),
        ["cover"] = doc:select(".block01 img"):first():attr("src") .. "&mobile=2",
        ["host"] = "http://truyenqq.com",
        ["author"] = doc:select("a.org"):text(),
        ["description"] = doc:select("div.story-detail-info"):html(),
        ["detail"] = doc:select(".block01 div.txt"):first():html(),
        ["ongoing"] = text:contains(doc:select("div.block01"):html(), "Đang Cập Nhật")
    }
    return response:success(book)
end
return nil