local key, page = ...
if text:is_empty(page) then
    page = 1
end
local doc = http:get("http://truyenqq.com/tim-kiem/trang-" .. page .. ".html?q=" .. key):html()

if doc ~= nil then
    local el = doc:select("ul.list-stories .story-item")
    local novelList = {}
    local next

    local last = doc:select(".pagination-list"):select("li:has(a.is-current) + li"):last():select("a")
    if last ~= nil then
        next = last:text()
    end
    for i = 0, el:size() - 1 do
        local e = el:get(i)
        local novel = {
            ["name"] = e:select(".title-book"):text(),
            ["link"] = e:select(".title-book a"):first():attr("href"),
            ["description"] = e:select(".episode-book"):text(),
            ["cover"] = e:select("img.story-cover"):attr("src") .. "&mobile=2",
            ["host"] = "https://truyenqq.com"
        }
        table.insert(novelList, novel)
    end

    return response:success(novelList, next)
end

return nil
