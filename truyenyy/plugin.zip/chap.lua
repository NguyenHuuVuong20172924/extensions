local url = ...
local doc = http:get(text:replace(url, "truyenyy.com", "truyenyy.vn")):timeout(0):html()
if doc ~= nil then
    local txt = doc:select("div.inner"):html()
    if (txt == nil or string.len(txt) < 1000) then
        if (text:contains(doc:html(), "btn_buy")) then
            return response:error(url)
        end
        if (text:contains(txt, "/login/")) then
            return response:error(url)
        end
        local id = regexp:find(doc:html(), "chap_id=(.*?)&")
        local part = num:to_int(regexp:find_last(doc:html(), "&part=(\\d)\""), 0)
        txt = ""
        for i = 0, part do
            local content = http:get("https://truyenyy.vn/web-api/novel/chapter-content-get/?chap_id=" .. id .. "&part=" .. i):timeout(0):table()
            if (content ~= nil) then
                txt = txt .. text:remove(content['content'], {"<style>.*?</style>", "<[a-z]{2,} style=.*?>.*?</[a-z]{2,}>", "</?[a-z]{2,}>"})
            end
        end

    end

    return response:success(txt)
end
return nil