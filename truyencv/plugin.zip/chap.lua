local url = ...
local doc = http:get(url):html()
if doc ~= nil then
    local element = doc:select("div.content"):first()
    if (string.len(element:text()) < 2000) then
        return response:error(url)
    end

    html:remove(element, { "div", "script", "font", "center", "button", "a" })
    if (element:select("p"):size() < 20) then
        element:select("p"):remove()
    end

    local title = doc:select("div.header h2.title"):first():text()

    return response:success(element:html(), title)
end
return nil