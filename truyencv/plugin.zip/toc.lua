local url = ...
local list = {}
local doc = http:get(url):html()
if doc ~= nil then
    local hash = regexp:find(doc:select("div.truyencv-detail-tab"):html(), "showChapter\\((.*?)\\)")
    if (text:is_empty(hash)) then
        return list
    end
    hash = text:remove(hash, { "'" })
    local tbl = text:split(hash, ",")

    local params = { ["showChapter"] = 1, ["media_id"] = tbl[1], ["number"] = 1, ["page"] = 1, ["type"] = tbl[4] }

    doc = http:post("https://truyencv.com/index.php"):params(params):html()
    local el = doc:select("div.item a")
    html:remove(el, { "span.text-muted" })

    if (doc:select("div.panel-vip"):isEmpty()) then
        for i = el:size() - 1, 0, -1 do
            local e = el:get(i)
            local e = el:get(i)
            local chap = {}
            chap["name"] = e:text()
            chap["url"] = e:attr("href")
            chap["host"] = "http://truyencv.com"
            table.insert(list, chap)
        end
    else
        for i = 0, el:size() - 1 do
            local e = el:get(i)
            local e = el:get(i)
            local chap = {}
            chap["name"] = e:text()
            chap["url"] = e:attr("href")
            chap["host"] = "http://truyencv.com"
            table.insert(list, chap)
        end
    end
    return response:success(list)
end
return nil